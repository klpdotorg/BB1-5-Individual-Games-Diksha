var Time_MT5_1_G5_JSON = {
	starAnimJson: {
		"frames": [

			{
				"filename": "Symbol 10 copy instance 10000",
				"frame": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10001",
				"frame": { "x": 0, "y": 116, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10002",
				"frame": { "x": 0, "y": 232, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10003",
				"frame": { "x": 0, "y": 348, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10004",
				"frame": { "x": 33, "y": 0, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10005",
				"frame": { "x": 33, "y": 116, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10006",
				"frame": { "x": 33, "y": 232, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10007",
				"frame": { "x": 33, "y": 348, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10008",
				"frame": { "x": 66, "y": 0, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10009",
				"frame": { "x": 66, "y": 116, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10010",
				"frame": { "x": 66, "y": 232, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10011",
				"frame": { "x": 66, "y": 348, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10012",
				"frame": { "x": 99, "y": 0, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10013",
				"frame": { "x": 99, "y": 116, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10014",
				"frame": { "x": 99, "y": 232, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10015",
				"frame": { "x": 99, "y": 348, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10016",
				"frame": { "x": 132, "y": 0, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10017",
				"frame": { "x": 132, "y": 116, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10018",
				"frame": { "x": 132, "y": 232, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10019",
				"frame": { "x": 132, "y": 348, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10020",
				"frame": { "x": 165, "y": 0, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10021",
				"frame": { "x": 165, "y": 116, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10022",
				"frame": { "x": 165, "y": 232, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10023",
				"frame": { "x": 165, "y": 348, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10024",
				"frame": { "x": 198, "y": 0, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10025",
				"frame": { "x": 198, "y": 116, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10026",
				"frame": { "x": 198, "y": 232, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10027",
				"frame": { "x": 198, "y": 348, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10028",
				"frame": { "x": 231, "y": 0, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10029",
				"frame": { "x": 231, "y": 116, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10030",
				"frame": { "x": 231, "y": 232, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10031",
				"frame": { "x": 231, "y": 348, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10032",
				"frame": { "x": 264, "y": 0, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10033",
				"frame": { "x": 264, "y": 116, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10034",
				"frame": { "x": 264, "y": 232, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10035",
				"frame": { "x": 264, "y": 348, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "15.1.0.210",
			"image": "st.png",
			"format": "RGB8",
			"size": { "w": 334, "h": 479 },
			"scale": "1"
		}
	},

	speakerJson: {
		"frames": [

			{
				"filename": "Symbol 5 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 41, "h": 30 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 41, "h": 30 },
				"sourceSize": { "w": 41, "h": 30 }
			},
			{
				"filename": "Symbol 5 instance 10001",
				"frame": { "x": 0, "y": 30, "w": 41, "h": 30 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 41, "h": 30 },
				"sourceSize": { "w": 41, "h": 30 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "15.1.0.210",
			"image": "s.png",
			"format": "RGB8",
			"size": { "w": 44, "h": 64 },
			"scale": "1"
		}
	},

	btnJson: {
		"frames": [

			{
				"filename": "Symbol 1 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 212, "h": 71 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 212, "h": 71 },
				"sourceSize": { "w": 212, "h": 71 }
			}
			, {
				"filename": "Symbol 1 instance 10001",
				"frame": { "x": 0, "y": 71, "w": 212, "h": 71 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 212, "h": 71 },
				"sourceSize": { "w": 212, "h": 71 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "16.5.1.104",
			"image": "b1.png",
			"format": "RGB8",
			"size": { "w": 213, "h": 144 },
			"scale": "1"
		}
	},

	replyJson: {
		"frames": [

			{
				"filename": "Symbol 8 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 47, "h": 47 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 47, "h": 47 },
				"sourceSize": { "w": 47, "h": 47 }
			}
			, {
				"filename": "Symbol 8 instance 10001",
				"frame": { "x": 47, "y": 0, "w": 47, "h": 47 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 47, "h": 47 },
				"sourceSize": { "w": 47, "h": 47 }
			}
			, {
				"filename": "Symbol 8 instance 10002",
				"frame": { "x": 0, "y": 0, "w": 47, "h": 47 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 47, "h": 47 },
				"sourceSize": { "w": 47, "h": 47 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "15.1.0.210",
			"image": "Back btn.png",
			"format": "RGBA8888",
			"size": { "w": 98, "h": 48 },
			"scale": "1"
		}
	},

	backbtnJson: {
		"frames": [

			{
				"filename": "Symbol 9 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 41, "h": 29 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 41, "h": 29 },
				"sourceSize": { "w": 41, "h": 29 }
			}
			, {
				"filename": "Symbol 9 instance 10001",
				"frame": { "x": 0, "y": 29, "w": 41, "h": 29 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 41, "h": 29 },
				"sourceSize": { "w": 41, "h": 29 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "15.1.0.210",
			"image": "back.png",
			"format": "RGB8",
			"size": { "w": 44, "h": 64 },
			"scale": "1"
		}
	},

	tickJson: {
		"frames": [

			{
				"filename": "Symbol 10 copy instance 10000",
				"frame": { "x": 0, "y": 0, "w": 68, "h": 66 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 68, "h": 66 },
				"sourceSize": { "w": 68, "h": 66 }
			}
			, {
				"filename": "Symbol 10 copy instance 10001",
				"frame": { "x": 68, "y": 0, "w": 68, "h": 66 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 68, "h": 66 },
				"sourceSize": { "w": 68, "h": 66 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "20.0.1.19255",
			"image": "Right btn0002.png",
			"format": "RGBA8888",
			"size": { "w": 138, "h": 66 },
			"scale": "1"
		}
	},


	nextbtnJson: {
		"frames": [

			{
				"filename": "Symbol 6 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 59, "h": 60 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 59, "h": 60 },
				"sourceSize": { "w": 59, "h": 60 }
			}
			, {
				"filename": "Symbol 6 instance 10001",
				"frame": { "x": 0, "y": 60, "w": 59, "h": 60 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 59, "h": 60 },
				"sourceSize": { "w": 59, "h": 60 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "18.0.1.115",
			"image": "N.png",
			"format": "RGB8",
			"size": { "w": 64, "h": 128 },
			"scale": "1"
		}
	},
	homebtnJson: {
		"frames": [

			{
				"filename": "Symbol 4 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 60, "h": 60 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 60, "h": 60 },
				"sourceSize": { "w": 60, "h": 60 }
			}
			, {
				"filename": "Symbol 4 instance 10001",
				"frame": { "x": 0, "y": 60, "w": 60, "h": 60 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 60, "h": 60 },
				"sourceSize": { "w": 60, "h": 60 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "18.0.1.115",
			"image": "H.png",
			"format": "RGB8",
			"size": { "w": 64, "h": 128 },
			"scale": "1"
		}

	},

	TickbtnJson: {
		"frames": [

			{
				"filename": "Symbol 10 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 67, "h": 68 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 67, "h": 68 },
				"sourceSize": { "w": 67, "h": 68 }
			}
			, {
				"filename": "Symbol 10 instance 10001",
				"frame": { "x": 67, "y": 0, "w": 67, "h": 68 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 67, "h": 68 },
				"sourceSize": { "w": 67, "h": 68 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "20.0.1.19255",
			"image": "ALP-01-G6.png",
			"format": "RGBA8888",
			"size": { "w": 134, "h": 68 },
			"scale": "1"
		}
	},

	bulbBtnJson: {
		"frames": [

			{
				"filename": "Symbol 1 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 66, "h": 49 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 66, "h": 49 },
				"sourceSize": { "w": 66, "h": 49 }
			}
			, {
				"filename": "Symbol 1 instance 10001",
				"frame": { "x": 66, "y": 0, "w": 66, "h": 49 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 66, "h": 49 },
				"sourceSize": { "w": 66, "h": 49 }
			}
			, {
				"filename": "Symbol 1 instance 10002",
				"frame": { "x": 132, "y": 0, "w": 66, "h": 49 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 66, "h": 49 },
				"sourceSize": { "w": 66, "h": 49 }
			}
			, {
				"filename": "Symbol 1 instance 10003",
				"frame": { "x": 0, "y": 49, "w": 66, "h": 49 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 66, "h": 49 },
				"sourceSize": { "w": 66, "h": 49 }
			}
			, {
				"filename": "Symbol 1 instance 10004",
				"frame": { "x": 66, "y": 49, "w": 66, "h": 49 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 66, "h": 49 },
				"sourceSize": { "w": 66, "h": 49 }
			}
			, {
				"filename": "Symbol 1 instance 10005",
				"frame": { "x": 132, "y": 49, "w": 66, "h": 49 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 66, "h": 49 },
				"sourceSize": { "w": 66, "h": 49 }
			}
			, {
				"filename": "Symbol 1 instance 10006",
				"frame": { "x": 0, "y": 98, "w": 66, "h": 49 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 66, "h": 49 },
				"sourceSize": { "w": 66, "h": 49 }
			}
			, {
				"filename": "Symbol 1 instance 10007",
				"frame": { "x": 66, "y": 98, "w": 66, "h": 49 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 66, "h": 49 },
				"sourceSize": { "w": 66, "h": 49 }
			}
			, {
				"filename": "Symbol 1 instance 10008",
				"frame": { "x": 132, "y": 98, "w": 66, "h": 49 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 66, "h": 49 },
				"sourceSize": { "w": 66, "h": 49 }
			}
			, {
				"filename": "Symbol 1 instance 10009",
				"frame": { "x": 0, "y": 147, "w": 66, "h": 49 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 66, "h": 49 },
				"sourceSize": { "w": 66, "h": 49 }
			}
			, {
				"filename": "Symbol 1 instance 10010",
				"frame": { "x": 66, "y": 147, "w": 66, "h": 49 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 66, "h": 49 },
				"sourceSize": { "w": 66, "h": 49 }
			}
			, {
				"filename": "Symbol 1 instance 10011",
				"frame": { "x": 132, "y": 147, "w": 66, "h": 49 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 66, "h": 49 },
				"sourceSize": { "w": 66, "h": 49 }
			}
			, {
				"filename": "Symbol 1 instance 10012",
				"frame": { "x": 0, "y": 196, "w": 66, "h": 49 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 66, "h": 49 },
				"sourceSize": { "w": 66, "h": 49 }
			}
			, {
				"filename": "Symbol 1 instance 10013",
				"frame": { "x": 66, "y": 196, "w": 66, "h": 49 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 66, "h": 49 },
				"sourceSize": { "w": 66, "h": 49 }
			}
			, {
				"filename": "Symbol 1 instance 10014",
				"frame": { "x": 132, "y": 196, "w": 66, "h": 49 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 66, "h": 49 },
				"sourceSize": { "w": 66, "h": 49 }
			}
			, {
				"filename": "Symbol 1 instance 10015",
				"frame": { "x": 0, "y": 245, "w": 66, "h": 49 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 66, "h": 49 },
				"sourceSize": { "w": 66, "h": 49 }
			}
			, {
				"filename": "Symbol 1 instance 10016",
				"frame": { "x": 66, "y": 245, "w": 66, "h": 49 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 66, "h": 49 },
				"sourceSize": { "w": 66, "h": 49 }
			}
			, {
				"filename": "Symbol 1 instance 10017",
				"frame": { "x": 132, "y": 245, "w": 66, "h": 49 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 66, "h": 49 },
				"sourceSize": { "w": 66, "h": 49 }
			}
			, {
				"filename": "Symbol 1 instance 10018",
				"frame": { "x": 0, "y": 294, "w": 66, "h": 49 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 66, "h": 49 },
				"sourceSize": { "w": 66, "h": 49 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "18.0.0.107",
			"image": "bulb anim.png",
			"format": "RGBA8888",
			"size": { "w": 198, "h": 347 },
			"scale": "1"
		}
	},

	Box2: {
		"frames": [

			{
				"filename": "Symbol 1 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 212, "h": 216 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 212, "h": 216 },
				"sourceSize": { "w": 212, "h": 216 }
			}
			, {
				"filename": "Symbol 1 instance 10001",
				"frame": { "x": 212, "y": 0, "w": 212, "h": 216 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 212, "h": 216 },
				"sourceSize": { "w": 212, "h": 216 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "22.0.0.93",
			"image": "box 2.png",
			"format": "RGBA8888",
			"size": { "w": 425, "h": 218 },
			"scale": "1"
		}
	},
	Box1: {
		"frames": [

			{
				"filename": "Symbol 7 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 211, "h": 216 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 211, "h": 216 },
				"sourceSize": { "w": 211, "h": 216 }
			}
			, {
				"filename": "Symbol 7 instance 10001",
				"frame": { "x": 211, "y": 0, "w": 211, "h": 216 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 211, "h": 216 },
				"sourceSize": { "w": 211, "h": 216 }
			}
			, {
				"filename": "Symbol 7 instance 10002",
				"frame": { "x": 422, "y": 0, "w": 211, "h": 216 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 211, "h": 216 },
				"sourceSize": { "w": 211, "h": 216 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "22.0.0.93",
			"image": "box_1.png",
			"format": "RGBA8888",
			"size": { "w": 633, "h": 218 },
			"scale": "1"
		}
	},
	analogClock: {
		"frames": [

			{
				"filename": "Symbol 27 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 301, "h": 325 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 301, "h": 325 },
				"sourceSize": { "w": 301, "h": 325 }
			}
			, {
				"filename": "Symbol 27 instance 10001",
				"frame": { "x": 301, "y": 0, "w": 301, "h": 325 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 301, "h": 325 },
				"sourceSize": { "w": 301, "h": 325 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "24.0.13.5",
			"image": "Analog clock 1.png",
			"format": "RGBA8888",
			"size": { "w": 602, "h": 327 },
			"scale": "1"
		}
	},
	digitalClock: {
		"frames": [

			{
				"filename": "Symbol 25 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 355, "h": 310 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 355, "h": 310 },
				"sourceSize": { "w": 355, "h": 310 }
			}
			, {
				"filename": "Symbol 25 instance 10001",
				"frame": { "x": 355, "y": 0, "w": 355, "h": 310 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 355, "h": 310 },
				"sourceSize": { "w": 355, "h": 310 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "24.0.13.5",
			"image": "Digital clock 1.png",
			"format": "RGBA8888",
			"size": { "w": 714, "h": 310 },
			"scale": "1"
		}
	},
	mrRight: {
		"frames": [

			{
				"filename": "Symbol 87 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 369, "h": 494 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 369, "h": 494 },
				"sourceSize": { "w": 369, "h": 494 }
			}
			, {
				"filename": "Symbol 87 instance 10001",
				"frame": { "x": 369, "y": 0, "w": 369, "h": 494 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 369, "h": 494 },
				"sourceSize": { "w": 369, "h": 494 }
			}
			, {
				"filename": "Symbol 87 instance 10002",
				"frame": { "x": 738, "y": 0, "w": 369, "h": 494 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 369, "h": 494 },
				"sourceSize": { "w": 369, "h": 494 }
			}
			, {
				"filename": "Symbol 87 instance 10003",
				"frame": { "x": 1107, "y": 0, "w": 369, "h": 494 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 369, "h": 494 },
				"sourceSize": { "w": 369, "h": 494 }
			}
			, {
				"filename": "Symbol 87 instance 10004",
				"frame": { "x": 1476, "y": 0, "w": 369, "h": 494 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 369, "h": 494 },
				"sourceSize": { "w": 369, "h": 494 }
			}
			, {
				"filename": "Symbol 87 instance 10005",
				"frame": { "x": 0, "y": 494, "w": 369, "h": 494 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 369, "h": 494 },
				"sourceSize": { "w": 369, "h": 494 }
			}
			, {
				"filename": "Symbol 87 instance 10006",
				"frame": { "x": 369, "y": 494, "w": 369, "h": 494 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 369, "h": 494 },
				"sourceSize": { "w": 369, "h": 494 }
			}
			, {
				"filename": "Symbol 87 instance 10007",
				"frame": { "x": 738, "y": 494, "w": 369, "h": 494 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 369, "h": 494 },
				"sourceSize": { "w": 369, "h": 494 }
			}
			, {
				"filename": "Symbol 87 instance 10008",
				"frame": { "x": 1107, "y": 494, "w": 369, "h": 494 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 369, "h": 494 },
				"sourceSize": { "w": 369, "h": 494 }
			}
			, {
				"filename": "Symbol 87 instance 10009",
				"frame": { "x": 1476, "y": 494, "w": 369, "h": 494 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 369, "h": 494 },
				"sourceSize": { "w": 369, "h": 494 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "24.0.12.3",
			"image": "Right Answer.png",
			"format": "RGBA8888",
			"size": { "w": 1845, "h": 989 },
			"scale": "1"
		}
	},
	mrWrong: {
		"frames": [

			{
				"filename": "Symbol 88 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 379, "h": 495 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 379, "h": 495 },
				"sourceSize": { "w": 379, "h": 495 }
			}
			, {
				"filename": "Symbol 88 instance 10001",
				"frame": { "x": 379, "y": 0, "w": 379, "h": 495 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 379, "h": 495 },
				"sourceSize": { "w": 379, "h": 495 }
			}
			, {
				"filename": "Symbol 88 instance 10002",
				"frame": { "x": 758, "y": 0, "w": 379, "h": 495 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 379, "h": 495 },
				"sourceSize": { "w": 379, "h": 495 }
			}
			, {
				"filename": "Symbol 88 instance 10003",
				"frame": { "x": 1137, "y": 0, "w": 379, "h": 495 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 379, "h": 495 },
				"sourceSize": { "w": 379, "h": 495 }
			}
			, {
				"filename": "Symbol 88 instance 10004",
				"frame": { "x": 1516, "y": 0, "w": 379, "h": 495 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 379, "h": 495 },
				"sourceSize": { "w": 379, "h": 495 }
			}
			, {
				"filename": "Symbol 88 instance 10005",
				"frame": { "x": 0, "y": 495, "w": 379, "h": 495 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 379, "h": 495 },
				"sourceSize": { "w": 379, "h": 495 }
			}
			, {
				"filename": "Symbol 88 instance 10006",
				"frame": { "x": 379, "y": 495, "w": 379, "h": 495 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 379, "h": 495 },
				"sourceSize": { "w": 379, "h": 495 }
			}
			, {
				"filename": "Symbol 88 instance 10007",
				"frame": { "x": 758, "y": 495, "w": 379, "h": 495 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 379, "h": 495 },
				"sourceSize": { "w": 379, "h": 495 }
			}
			, {
				"filename": "Symbol 88 instance 10008",
				"frame": { "x": 1137, "y": 495, "w": 379, "h": 495 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 379, "h": 495 },
				"sourceSize": { "w": 379, "h": 495 }
			}
			, {
				"filename": "Symbol 88 instance 10009",
				"frame": { "x": 1516, "y": 495, "w": 379, "h": 495 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 379, "h": 495 },
				"sourceSize": { "w": 379, "h": 495 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "24.0.12.3",
			"image": "Wrong Answer.png",
			"format": "RGBA8888",
			"size": { "w": 1897, "h": 990 },
			"scale": "1"
		}
	}

};

